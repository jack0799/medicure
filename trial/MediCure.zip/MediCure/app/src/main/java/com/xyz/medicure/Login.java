package com.xyz.medicure;

import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuth.AuthStateListener;

public class Login extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private AuthStateListener mAuthListener;
    private EditText memail;
    private Button mlogin;
    private EditText mpassword;
    private Button msignup;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        this.mAuth = FirebaseAuth.getInstance();
        this.memail = (EditText) findViewById(R.id.Email);
        this.mpassword = (EditText) findViewById(R.id.pswd);
        this.mlogin = (Button) findViewById(R.id.Login);
        this.msignup = (Button) findViewById(R.id.signup);
        this.mAuthListener = new AuthStateListener() {
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                if (firebaseAuth.getCurrentUser() != null) {
                    Login.this.startActivity(new Intent(Login.this, Home.class));
                }
            }
        };
        this.mlogin.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Login.this.startSignIn();
            }
        });
        this.msignup.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Login.this.startActivity(new Intent(Login.this, Register.class));
            }
        });
    }

    /* access modifiers changed from: protected */
    public void onStart() {
        super.onStart();
        this.mAuth.addAuthStateListener(this.mAuthListener);
    }

    /* access modifiers changed from: private */
    public void startSignIn() {
        String email = this.memail.getText().toString();
        String password = this.mpassword.getText().toString();
        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Fields are empty", Toast.LENGTH_SHORT).show();
        } else {
            this.mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (!task.isSuccessful()) {
                        Toast.makeText(Login.this, "Sign In Problem", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }
}