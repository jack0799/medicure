package com.xyz.medicure;

/**
 * Created by DELL on 14-10-2018.
 */

public class Symptom {
    private String Symptom;

    public Symptom(){

    }

    public Symptom(String symptom) {
        Symptom = symptom;
    }

    public String getSymptom() {
        return Symptom;
    }

    public void setSymptom(String symptom) {
        Symptom = symptom;
    }
}
