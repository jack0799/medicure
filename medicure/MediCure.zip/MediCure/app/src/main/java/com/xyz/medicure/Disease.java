package com.xyz.medicure;

/**
 * Created by DELL on 14-10-2018.
 */

public class Disease {
    private String Disease;

    public Disease(){

    }

    public Disease(String disease) {
        Disease = disease;
    }

    public String getDisease() {
        return Disease;
    }

    public void setDisease(String disease) {
        Disease = disease;
    }
}
